from setuptools import setup

setup(name="pkgb", install_requires=["pkga"])
